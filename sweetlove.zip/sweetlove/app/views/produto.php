<?php

    require_once "../models/CrudProdutos.php";

    $crud = new CrudProdutos();

    //seguranca
    $codigo = filter_input(INPUT_GET, 'codigo', FILTER_VALIDATE_INT); //consulte os slides.

    $produto = $crud->getProduto($codigo); //A variavel produto recebe o que retornar da funcao getProduto

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Cafeteria Sweet Love</title>

    <!-- Bootstrap core CSS -->
    <link href="../../assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="../../assets/vendor/bootstrap/css/bootstrap-grid.css" rel="stylesheet">
    <link href="../../assets/vendor/bootstrap/css/bootstrap-reboot.css" rel="stylesheet">
    <link href="../../assets/css/ifc-style.css" rel="stylesheet">

</head>

<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#"><img src="../../assets/imagens/logo2.png" alt="" width="80px"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="../../index.php">Início</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin/produtos.php">Área do Admin</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Page Content -->
<div class="container product-content">
    <br><br><br><br><br>  <br><br><br><br><br>

    <!-- Page Features -->
    <div class="row">

        <div class="col-md-5">
            <img src="../../assets/imagens/foto_padrao.jpg  " alt="" class="img-fluid">
        </div>


        <div class="col-md-7">
            <div class="row">
                <div class="col-md-12">
                    <h2><?= $produto->nome ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <span class="badge badge-primary"<h2><?= $produto->categoria;?></h2></span>
                    <span class="badge badge-warning"<h2><?= $produto->estaDisponivel();?></h2></span>
                </div>
            </div>
            <!-- end row -->

            <div class="row description-wrapper">
                <div class="col-md-12">
                    <p class="description">Consectetur adipisicing elit. Accusantium ad, adipisci commodi delectus ea eius eligendi expedita in ipsum magnam
                        modi mollitia nisi, obcaecati perspiciatis quae quo repellendus temporibus velit.
                    </p>
                </div>
            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-md-12 bottom-rule">
                    <h2 class="product-price" <h2><?= $produto->preco;?></h2>Quantidade</h2>
                </div>
            </div>
            <!-- end row -->
            <form action="../controllers/controladorProduto.php?acao=comprar" method="post">

            <div class="row add-to-carts  ">
                <div class="col-md-5 product-qty">
                    <input name="quantidade" class="btn btn-default btn-lg btn-qty" value="1" />

                    <input type="hidden" name="codigo" value="<?= $produto->codigo ?> ">
                <br><br>
                    <button class="btn btn-lg btn-brand btn-full-width" <?php $produto->estoque;?>>
                        comprar
                    </button>
                </div>
            </div><!-- end row -->
            </form>
        </div>


    </div>
    <!-- /.row -->

</div>
<!-- /.container -->

<!-- Footer -->
<br><br><br>  <br><br><br><br><br><br><br>
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Cafeteria Sweet Love</p>
    </div>
    <!-- /.container -->
</footer>

</body>

</html>
