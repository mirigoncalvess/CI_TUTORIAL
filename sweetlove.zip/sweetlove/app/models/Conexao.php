<?php

class Conexao {

    const HOST      = "localhost";
    const NOMEBANCO = "BD_SweetLove";
    const USUARIO   = "root";
    const SENHA     = "";


    
    //!!!Substitua daqui para baixo


    public static function getConexao(){

        $conexao = new PDO("mysql:host=".self::HOST.";dbname=".self::NOMEBANCO, self::USUARIO, self::SENHA);
        $conexao->exec("SET CHARACTER SET utf8");
        return $conexao;
    }
}


//teste conexao
//$con = new Conexao();
//$con->getConexao();
