<?php

require_once "Conexao.php";

class Produto {

    public $codigo;
    public $nome;
    public $preco;
    public $categoria;
    public $estoque;

    public function __construct($nome, $preco, $categoria, $estoque, $codigo = null){
        $this->nome = $nome;
        $this->preco = $preco;
        $this->categoria = $categoria;
        $this->estoque = $estoque;
        $this->codigo = $codigo;
    }


    public function estaDisponivel(){
      //se o $this->estoque for maior que zero então retorne disponivel -- FEITO--
        if ($this->estoque > 0){
            echo "Disponível";
        } else {
            echo "Indisponível";
        }
     }

}