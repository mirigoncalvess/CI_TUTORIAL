-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 24/11/2017 às 15:52
-- Versão do servidor: 5.7.17-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.13-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `BD_SweetLove`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_produtos`
--

CREATE TABLE `tb_produtos` (
  `codigo` int(11) NOT NULL,
  `nome` varchar(32) NOT NULL,
  `categoria` varchar(32) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoque` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `tb_produtos`
--

INSERT INTO `tb_produtos` (`codigo`, `nome`, `categoria`, `preco`, `estoque`) VALUES
(1, 'Torta Alemã', 'torta', '25.00', 3),
(2, 'Dois Amores', 'bolo', '50.00', 2),
(3, 'Brigadeiro', 'bolo', '50.00', 20),
(4, 'Mousse Maracuja', 'mousse', '5.00', 10),
(5, 'Maria Mole', 'doce', '1.00', 30),
(6, 'Olho de Sogra', 'doce', '0.50', 20),
(7, 'Pão de Queijo', 'salgado', '0.50', 20),
(8, 'Café', 'bebida', '2.00', 30),
(9, 'Capuccino', 'bebida', '5.00', 30),
(16, 'Croissant', 'salgado', '3.50', 20),
(17, 'Coxinha', 'salgado', '2.50', 15),
(18, 'Empadão', 'salgado', '5.00', 10),
(19, 'Bolinho de Carne', 'salgado', '3.00', 10),
(20, 'Mousse Chocolate', 'mousse', '5.00', 10),
(21, 'Toddynho', 'bebida', '2.00', 20);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD PRIMARY KEY (`codigo`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
